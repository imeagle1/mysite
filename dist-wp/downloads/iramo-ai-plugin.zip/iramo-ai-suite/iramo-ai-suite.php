<?php
/**
 * Plugin Name: iRamoAi Suite (LMS, AI Tools, Articles & Elementor Pro)
 * Plugin URI:  https://iramo.ai
 * Description: Complete WordPress plugin for iRamoAi: Full App & User Panel Shortcodes, Native Elementor Pro Widgets, WooCommerce Auto-Enrollment, Telegram/Bale Bot Bridge & Demo Data Manager.
 * Version:     2.1.0
 * Author:      iRamoAi Engineering
 * Text Domain: iramo-ai
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IRAMO_AI_VERSION', '2.0.0' );
define( 'IRAMO_AI_PATH', plugin_dir_path( __FILE__ ) );
define( 'IRAMO_AI_URL', plugin_dir_url( __FILE__ ) );

// Load modular includes
if ( file_exists( IRAMO_AI_PATH . 'includes/admin-settings.php' ) ) {
    require_once IRAMO_AI_PATH . 'includes/admin-settings.php';
}
if ( file_exists( IRAMO_AI_PATH . 'includes/bot-bridge.php' ) ) {
    require_once IRAMO_AI_PATH . 'includes/bot-bridge.php';
}
if ( file_exists( IRAMO_AI_PATH . 'includes/elementor-widgets.php' ) ) {
    require_once IRAMO_AI_PATH . 'includes/elementor-widgets.php';
}

/**
 * 1. Register Custom Post Types: Courses, AI Tools, Articles & Products
 */
add_action( 'init', function() {
    register_post_type( 'iramo_course', [
        'labels' => [
            'name'          => __( 'دوره‌های آموزشی iRamo', 'iramo-ai' ),
            'singular_name' => __( 'دوره آموزشی', 'iramo-ai' ),
            'add_new_item'  => __( 'افزودن دوره جدید', 'iramo-ai' ),
        ],
        'public'       => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-welcome-learn-more',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'academy' ],
    ] );

    register_post_type( 'iramo_ai_tool', [
        'labels' => [
            'name'          => __( 'ابزارهای هوش مصنوعی', 'iramo-ai' ),
            'singular_name' => __( 'ابزار AI', 'iramo-ai' ),
        ],
        'public'       => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-superhero-alt',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
    ] );

    register_post_type( 'iramo_article', [
        'labels' => [
            'name'          => __( 'مقالات تخصصی iRamo', 'iramo-ai' ),
            'singular_name' => __( 'مقاله', 'iramo-ai' ),
        ],
        'public'       => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-media-document',
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'author', 'custom-fields' ],
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'articles' ],
    ] );

    register_taxonomy( 'iramo_tool_task', 'iramo_ai_tool', [
        'label'        => __( 'نوع کار (Task)', 'iramo-ai' ),
        'show_in_rest' => true,
        'hierarchical' => true,
    ] );
} );

/**
 * 2. WooCommerce Order Completed -> Auto Enroll Student & Trigger Bot Bridge
 */
add_action( 'woocommerce_order_status_completed', function( $order_id ) {
    if ( ! function_exists( 'wc_get_order' ) ) return;
    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $user_id = $order->get_user_id();
    if ( ! $user_id ) return;

    $enrolled = get_user_meta( $user_id, '_iramo_enrolled_courses', true );
    if ( ! is_array( $enrolled ) ) $enrolled = [];

    foreach ( $order->get_items() as $item ) {
        $product_id = $item->get_product_id();
        $linked_course_id = get_post_meta( $product_id, '_iramo_linked_course_id', true );
        if ( $linked_course_id && ! in_array( (int) $linked_course_id, $enrolled, true ) ) {
            $enrolled[] = (int) $linked_course_id;
        }
    }

    update_user_meta( $user_id, '_iramo_enrolled_courses', $enrolled );
    do_action( 'iramo_lms_order_delivered', $order_id, $user_id, $enrolled );
} );

/**
 * 3. REST API for Progress Tracking, Site Config & Demo Data
 */
add_action( 'rest_api_init', function() {
    register_rest_route( 'iramo/v1', '/progress', [
        'methods'             => 'POST',
        'permission_callback' => function() { return is_user_logged_in(); },
        'callback'            => function( WP_REST_Request $request ) {
            $user_id   = get_current_user_id();
            $lesson_id = sanitize_text_field( $request->get_param( 'lesson_id' ) );
            $completed = (bool) $request->get_param( 'completed' );

            $progress = get_user_meta( $user_id, '_iramo_completed_lessons', true );
            if ( ! is_array( $progress ) ) $progress = [];

            if ( $completed ) {
                $progress[ $lesson_id ] = current_time( 'mysql' );
            } else {
                unset( $progress[ $lesson_id ] );
            }
            update_user_meta( $user_id, '_iramo_completed_lessons', $progress );

            return rest_ensure_response( [
                'success'   => true,
                'completed' => array_keys( $progress ),
            ] );
        },
    ] );
} );

/**
 * 4. Shortcode [iramo_lms] & [iramo_site]
 */
function iramo_render_app_shortcode( $atts ) {
    $options = get_option( 'iramo_ai_settings', [] );
    $atts = shortcode_atts( [
        'theme' => $options['default_theme'] ?? 'light',
        'lang'  => is_rtl() ? 'fa' : 'en',
        'view'  => 'home',
    ], $atts, 'iramo_lms' );

    $current_user = wp_get_current_user();
    $user_payload = is_user_logged_in() ? [
        'id'        => $current_user->ID,
        'name'      => $current_user->display_name,
        'email'     => $current_user->user_email,
        'enrolled'  => get_user_meta( $current_user->ID, '_iramo_enrolled_courses', true ) ?: [],
        'completed' => array_keys( get_user_meta( $current_user->ID, '_iramo_completed_lessons', true ) ?: [] ),
        'nonce'     => wp_create_nonce( 'wp_rest' ),
        'restUrl'   => esc_url_raw( rest_url( 'iramo/v1/' ) ),
    ] : null;

    $font_choice = $options['font_family'] ?? 'vazirmatn';
    $font_urls = [
        'vazirmatn'   => 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap',
        'rubik'       => 'https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700;800&display=swap',
        'readex'      => 'https://fonts.googleapis.com/css2?family=Readex+Pro:wght@400;500;600;700&display=swap',
        'noto-arabic' => 'https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@400;500;600;700;800&display=swap',
    ];
    if ( $font_choice === 'custom' && ! empty( $options['custom_font_css_url'] ) ) {
        wp_enqueue_style( 'iramo-custom-font', esc_url_raw( $options['custom_font_css_url'] ), [], null );
    } elseif ( isset( $font_urls[ $font_choice ] ) ) {
        wp_enqueue_style( 'iramo-active-font', $font_urls[ $font_choice ], [], null );
    }

    if ( file_exists( IRAMO_AI_PATH . 'assets/iramo-lms.js' ) ) {
        wp_enqueue_script( 'iramo-ai-bundle', IRAMO_AI_URL . 'assets/iramo-lms.js', [], IRAMO_AI_VERSION, true );
    }
    if ( file_exists( IRAMO_AI_PATH . 'assets/iramo-lms.css' ) ) {
        wp_enqueue_style( 'iramo-ai-styles', IRAMO_AI_URL . 'assets/iramo-lms.css', [], IRAMO_AI_VERSION );
    }

    $auth_config = [
        'telegram'            => ! isset( $options['enable_telegram_auth'] ) || ! empty( $options['enable_telegram_auth'] ),
        'bale'                => ! isset( $options['enable_bale_auth'] ) || ! empty( $options['enable_bale_auth'] ),
        'sms'                 => ! isset( $options['enable_sms_auth'] ) || ! empty( $options['enable_sms_auth'] ),
        'email'               => ! isset( $options['enable_email_auth'] ) || ! empty( $options['enable_email_auth'] ),
        'defaultChannel'      => $options['default_auth_channel'] ?? 'telegram',
        'allowRegistration'   => ! isset( $options['allow_registration'] ) || ! empty( $options['allow_registration'] ),
        'telegramBotUsername' => $options['telegram_bot_username'] ?? '@iRamoBot',
        'baleBotUsername'     => $options['bale_bot_username'] ?? '@iRamoBaleBot',
        'smsProvider'         => $options['sms_provider'] ?? 'kavenegar',
        'smsPatternCode'      => $options['sms_pattern_code'] ?? 'iramo-verify-otp',
    ];

    $raw_tips = array_filter( array_map( 'trim', explode( "\n", $options['quick_tips_text'] ?? '' ) ) );
    $quick_tips = [];
    foreach ( $raw_tips as $idx => $line ) {
        $quick_tips[] = [
            'id' => 'wp-tip-' . ( $idx + 1 ),
            'fa' => $line,
            'en' => $line,
        ];
    }

    $color_config = [
        'preset'          => $options['color_preset'] ?? 'emerald-classic',
        'primaryHex'      => $options['primary_color'] ?? '#059669',
        'accentHex'       => $options['accent_color'] ?? '#FFBA00',
        'lightCanvasHex'  => $options['light_canvas_color'] ?? '#F8FAFC',
        'borderIntensity' => $options['border_intensity'] ?? 'subtle',
    ];

    ob_start();
    ?>
    <div
      id="iramo-lms-root"
      data-theme="<?php echo esc_attr( $atts['theme'] ); ?>"
      data-lang="<?php echo esc_attr( $atts['lang'] ); ?>"
      data-view="<?php echo esc_attr( $atts['view'] ); ?>"
      data-font="<?php echo esc_attr( $font_choice ); ?>"
      data-custom-font="<?php echo esc_attr( $options['custom_font_name'] ?? '' ); ?>"
      data-brand-name="<?php echo esc_attr( $options['brand_name'] ?? 'iRamoAi' ); ?>"
      data-color-config="<?php echo esc_attr( wp_json_encode( $color_config ) ); ?>"
      data-auth-config="<?php echo esc_attr( wp_json_encode( $auth_config ) ); ?>"
      data-quick-tips="<?php echo esc_attr( wp_json_encode( $quick_tips ) ); ?>"
      data-demo-cleared="<?php echo ! empty( $options['demo_cleared'] ) ? '1' : '0'; ?>"
      data-plugin-url="<?php echo esc_url( IRAMO_AI_URL ); ?>"
      data-user="<?php echo esc_attr( wp_json_encode( $user_payload ) ); ?>"
      style="min-height: 100vh; width: 100%;"
    ></div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'iramo_lms', 'iramo_render_app_shortcode' );
add_shortcode( 'iramo_site', 'iramo_render_app_shortcode' );
