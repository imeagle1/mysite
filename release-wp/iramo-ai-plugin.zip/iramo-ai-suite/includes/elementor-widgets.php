<?php
/**
 * Module: Native Elementor & Elementor Pro Widgets for iRamoAi
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'elementor/elements/categories_registered', function( $elements_manager ) {
    $elements_manager->add_category( 'iramo-ai', [
        'title' => __( 'ابزارک‌های iRamoAi', 'iramo-ai' ),
        'icon'  => 'eicon-graduation-cap',
    ] );
} );

add_action( 'elementor/widgets/register', function( $widgets_manager ) {
    if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
        return;
    }

    // Widget 1: Full Portal / Dashboard Widget
    class iRamo_Elementor_App_Widget extends \Elementor\Widget_Base {
        public function get_name() { return 'iramo_lms_dashboard'; }
        public function get_title() { return __( 'اپلیکیشن و پنل کاربری iRamoAi', 'iramo-ai' ); }
        public function get_icon() { return 'eicon-apps'; }
        public function get_categories() { return [ 'iramo-ai' ]; }

        protected function register_controls() {
            $this->start_controls_section( 'section_config', [
                'label' => __( 'تنظیمات نمایش', 'iramo-ai' ),
            ] );

            $this->add_control( 'default_view', [
                'label'   => __( 'صفحه شروع', 'iramo-ai' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'home',
                'options' => [
                    'home'           => __( 'صفحه اصلی کامل سایت', 'iramo-ai' ),
                    'products'       => __( 'ویترین محصولات و دمو', 'iramo-ai' ),
                    'ai-marketplace' => __( 'ابزارهای هوش مصنوعی', 'iramo-ai' ),
                    'articles'       => __( 'مقالات و ابزارک‌ها', 'iramo-ai' ),
                    'course'         => __( 'کتابخانه دوره‌ها', 'iramo-ai' ),
                ],
            ] );

            $this->add_control( 'default_theme', [
                'label'   => __( 'تم سایت و پنل کاربری', 'iramo-ai' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'light',
                'options' => [
                    'light' => __( 'روشن مدرن (Modern Light)', 'iramo-ai' ),
                    'dark'  => __( 'سبز زمردی تیره', 'iramo-ai' ),
                ],
            ] );

            $this->end_controls_section();
        }

        protected function render() {
            $s = $this->get_settings_for_display();
            echo do_shortcode( sprintf(
                '[iramo_lms theme="%s" view="%s"]',
                esc_attr( $s['default_theme'] ),
                esc_attr( $s['default_view'] )
            ) );
        }
    }

    // Widget 2: Native WordPress Articles & Widgets Grid for Elementor
    class iRamo_Elementor_Articles_Widget extends \Elementor\Widget_Base {
        public function get_name() { return 'iramo_articles_grid'; }
        public function get_title() { return __( 'گرید مقالات و ابزارک‌ها (iRamo)', 'iramo-ai' ); }
        public function get_icon() { return 'eicon-posts-grid'; }
        public function get_categories() { return [ 'iramo-ai' ]; }

        protected function register_controls() {
            $this->start_controls_section( 'section_articles', [
                'label' => __( 'تنظیمات مقالات', 'iramo-ai' ),
            ] );
            $this->add_control( 'posts_count', [
                'label'   => __( 'تعداد مقالات', 'iramo-ai' ),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'default' => 6,
                'min'     => 1,
                'max'     => 12,
            ] );
            $this->end_controls_section();
        }

        protected function render() {
            $s = $this->get_settings_for_display();
            $query = new \WP_Query( [
                'post_type'      => [ 'iramo_article', 'post' ],
                'posts_per_page' => (int) ( $s['posts_count'] ?? 6 ),
            ] );
            echo '<div class="iramo-articles-elementor-grid" dir="rtl" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;">';
            if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
                    echo '<article style="background:var(--iramo-card-bg,#ffffff);border:1px solid var(--iramo-card-border,rgba(5,150,105,0.16));border-radius:16px;padding:18px;box-shadow:0 1px 3px rgba(15,23,42,0.06);">';
                    echo '<h3 style="margin:0 0 8px;font-size:16px;"><a href="' . esc_url( get_permalink() ) . '" style="color:inherit;text-decoration:none;">' . esc_html( get_the_title() ) . '</a></h3>';
                    echo '<p style="font-size:13px;opacity:0.75;margin:0 0 12px;">' . esc_html( get_the_excerpt() ) . '</p>';
                    echo '<a href="' . esc_url( get_permalink() ) . '" style="color:var(--iramo-primary,#059669);font-size:12px;font-weight:bold;text-decoration:none;">مطالعه مقاله ←</a>';
                    echo '</article>';
                }
                wp_reset_postdata();
            } else {
                echo '<p style="opacity:0.7;">هنوز مقاله‌ای منتشر نشده است.</p>';
            }
            echo '</div>';
        }
    }

    $widgets_manager->register( new iRamo_Elementor_App_Widget() );
    $widgets_manager->register( new iRamo_Elementor_Articles_Widget() );
} );
