<?php
/**
 * Module: iRamoAi Full WordPress Admin Control Panel & Demo Data Cleaner
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_menu', function() {
    add_menu_page(
        __( 'تنظیمات iRamoAi', 'iramo-ai' ),
        __( 'تنظیمات iRamoAi', 'iramo-ai' ),
        'manage_options',
        'iramo-ai-control',
        'iramo_render_admin_control_page',
        'dashicons-superhero-alt',
        3
    );
} );

add_action( 'admin_init', function() {
    register_setting( 'iramo_ai_settings_group', 'iramo_ai_settings' );
    register_setting( 'iramo_ai_settings_group', 'iramo_telegram_bot_token' );
    register_setting( 'iramo_ai_settings_group', 'iramo_bale_bot_token' );
    register_setting( 'iramo_ai_settings_group', 'iramo_admin_chat_id' );
} );

// Handle One-Click Demo Data Purge or Install
add_action( 'admin_post_iramo_manage_demo_data', function() {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    check_admin_referer( 'iramo_demo_nonce' );

    $action_type = sanitize_text_field( $_POST['demo_action'] ?? '' );
    $post_types  = [ 'iramo_product', 'iramo_course', 'iramo_ai_tool', 'iramo_article' ];

    if ( $action_type === 'purge_demo' ) {
        $demo_posts = get_posts( [
            'post_type'      => $post_types,
            'posts_per_page' => -1,
            'meta_key'       => '_iramo_is_demo',
            'meta_value'     => '1',
            'fields'         => 'ids',
        ] );
        foreach ( $demo_posts as $pid ) {
            wp_delete_post( $pid, true );
        }
        $opts = get_option( 'iramo_ai_settings', [] );
        $opts['demo_cleared'] = 1;
        update_option( 'iramo_ai_settings', $opts );
        wp_redirect( admin_url( 'admin.php?page=iramo-ai-control&demo_status=purged' ) );
        exit;
    }

    if ( $action_type === 'install_demo' ) {
        $samples = [
            [ 'post_type' => 'iramo_course', 'title' => 'دوره جامع هوش مصنوعی از صفر تا پیشرفته' ],
            [ 'post_type' => 'iramo_course', 'title' => 'ساخت ربات آموزشی و فروش تلگرام و بله' ],
            [ 'post_type' => 'iramo_article', 'title' => 'معماری اتصال ربات تلگرام و بله به ووکامرس' ],
            [ 'post_type' => 'iramo_ai_tool', 'title' => 'موتور حسابیار هوشمند OCR' ],
        ];
        foreach ( $samples as $item ) {
            $id = wp_insert_post( [
                'post_type'   => $item['post_type'],
                'post_title'  => $item['title'],
                'post_status' => 'publish',
            ] );
            if ( $id ) {
                update_post_meta( $id, '_iramo_is_demo', '1' );
            }
        }
        $opts = get_option( 'iramo_ai_settings', [] );
        $opts['demo_cleared'] = 0;
        update_option( 'iramo_ai_settings', $opts );
        wp_redirect( admin_url( 'admin.php?page=iramo-ai-control&demo_status=installed' ) );
        exit;
    }
} );

function iramo_render_admin_control_page() {
    $opts = get_option( 'iramo_ai_settings', [] );
    $status = sanitize_text_field( $_GET['demo_status'] ?? '' );
    ?>
    <div class="wrap" dir="rtl" style="max-width: 900px; font-family: Tahoma, sans-serif;">
        <h1>پنل کنترل کامل قالب و افزونه iRamoAi</h1>
        <?php if ( $status === 'purged' ) : ?>
            <div class="notice notice-success is-dismissible"><p>تمام داده‌های نمونه (دوره‌ها، مقالات، نکات سریع روز و ابزارهای پیش‌فرض) با موفقیت پاکسازی شدند.</p></div>
        <?php elseif ( $status === 'installed' ) : ?>
            <div class="notice notice-success is-dismissible"><p>داده‌های نمونه مجدداً نصب شدند.</p></div>
        <?php endif; ?>

        <form method="post" action="options.php" style="background:#fff;padding:24px;border-radius:12px;border:1px solid #dcdcde;margin-top:20px;">
            <?php settings_fields( 'iramo_ai_settings_group' ); ?>
            <h2>تنظیمات عمومی، فونت و ظاهر سایت</h2>
            <table class="form-table">
                <tr>
                    <th>نام برند سایت</th>
                    <td><input type="text" name="iramo_ai_settings[brand_name]" value="<?php echo esc_attr( $opts['brand_name'] ?? 'iRamoAi' ); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th>حالت پیش‌فرض سایت و پنل کاربری</th>
                    <td>
                        <select name="iramo_ai_settings[default_theme]">
                            <option value="light" <?php selected( $opts['default_theme'] ?? 'light', 'light' ); ?>>روشن مدرن (Modern Light)</option>
                            <option value="dark" <?php selected( $opts['default_theme'] ?? 'light', 'dark' ); ?>>تیره زمردی (Dark Emerald)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>فونت فارسی سایت و افزونه</th>
                    <td>
                        <select name="iramo_ai_settings[font_family]">
                            <option value="vazirmatn" <?php selected( $opts['font_family'] ?? 'vazirmatn', 'vazirmatn' ); ?>>وزیرمتن (Vazirmatn)</option>
                            <option value="rubik" <?php selected( $opts['font_family'] ?? 'vazirmatn', 'rubik' ); ?>>روبیک (Rubik)</option>
                            <option value="readex" <?php selected( $opts['font_family'] ?? 'vazirmatn', 'readex' ); ?>>ریدکس پرو (Readex Pro)</option>
                            <option value="noto-arabic" <?php selected( $opts['font_family'] ?? 'vazirmatn', 'noto-arabic' ); ?>>نوتو سنس فارسی (Noto Sans Arabic)</option>
                            <option value="custom" <?php selected( $opts['font_family'] ?? 'vazirmatn', 'custom' ); ?>>فونت اختصاصی آپلودشده (ایران‌سنس / یکان‌بخ / پیدا)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>نام فونت اختصاصی (Font Family)</th>
                    <td>
                        <input type="text" dir="ltr" name="iramo_ai_settings[custom_font_name]" value="<?php echo esc_attr( $opts['custom_font_name'] ?? '' ); ?>" class="regular-text" placeholder="IRANSansX" />
                        <p class="description">در صورت انتخاب فونت اختصاصی، نام font-family را اینجا بنویسید.</p>
                    </td>
                </tr>
                <tr>
                    <th>آدرس فایل CSS فونت اختصاصی (اختیاری)</th>
                    <td>
                        <input type="url" dir="ltr" name="iramo_ai_settings[custom_font_css_url]" value="<?php echo esc_attr( $opts['custom_font_css_url'] ?? '' ); ?>" class="regular-text" placeholder="assets/fonts/custom-font.css" />
                        <p class="description">اگر فایل‌های فونت (.woff2) را در پوشه گیت‌هاب <code>public/fonts/</code> آپلود کرده باشید، به‌صورت خودکار داخل بسته افزونه قرار می‌گیرد و خالی گذاشتن این فیلد کافی است.</p>
                    </td>
                </tr>
                <tr>
                    <th>پالت رنگ‌بندی سایت (قاعده ۶۰-۳۰-۱۰)</th>
                    <td>
                        <select name="iramo_ai_settings[color_preset]">
                            <option value="emerald-classic" <?php selected( $opts['color_preset'] ?? 'emerald-classic', 'emerald-classic' ); ?>>نسخه اول روشن (زمردی و طلایی مینیمال)</option>
                            <option value="logo-blue" <?php selected( $opts['color_preset'] ?? 'emerald-classic', 'logo-blue' ); ?>>آبی لوگو iRamoAi (یکدست)</option>
                            <option value="royal-slate" <?php selected( $opts['color_preset'] ?? 'emerald-classic', 'royal-slate' ); ?>>آبی لاجوردی و فیروزه‌ای</option>
                            <option value="teal-indigo" <?php selected( $opts['color_preset'] ?? 'emerald-classic', 'teal-indigo' ); ?>>تیل مدرن و نیلی ملایم</option>
                            <option value="custom" <?php selected( $opts['color_preset'] ?? 'emerald-classic', 'custom' ); ?>>رنگ دلخواه سفارشی</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>رنگ اصلی و رنگ دکمه‌های اقدام (Hex)</th>
                    <td>
                        <label style="margin-left:14px;">اصلی (Primary): <input type="color" name="iramo_ai_settings[primary_color]" value="<?php echo esc_attr( $opts['primary_color'] ?? '#059669' ); ?>" /></label>
                        <label style="margin-left:14px;">تاکیدی دکمه‌ها (Accent): <input type="color" name="iramo_ai_settings[accent_color]" value="<?php echo esc_attr( $opts['accent_color'] ?? '#FFBA00' ); ?>" /></label>
                        <label>شدت حاشیه کارت‌ها:
                            <select name="iramo_ai_settings[border_intensity]">
                                <option value="subtle" <?php selected( $opts['border_intensity'] ?? 'subtle', 'subtle' ); ?>>بسیار ملایم و ظریف</option>
                                <option value="balanced" <?php selected( $opts['border_intensity'] ?? 'subtle', 'balanced' ); ?>>متعادل</option>
                                <option value="defined" <?php selected( $opts['border_intensity'] ?? 'subtle', 'defined' ); ?>>مشخص‌تر</option>
                            </select>
                        </label>
                    </td>
                </tr>
            </table>

            <hr style="margin:24px 0;" />
            <h2>مدیریت ورود کاربران، ربات‌ها و پنل پیامکی (OTP)</h2>
            <table class="form-table">
                <tr>
                    <th>روش‌های ورود فعال در پنل</th>
                    <td>
                        <label style="display:inline-block;margin-left:16px;"><input type="checkbox" name="iramo_ai_settings[enable_telegram_auth]" value="1" <?php checked( ! isset( $opts['enable_telegram_auth'] ) || ! empty( $opts['enable_telegram_auth'] ) ); ?> /> ورود با ربات تلگرام</label>
                        <label style="display:inline-block;margin-left:16px;"><input type="checkbox" name="iramo_ai_settings[enable_bale_auth]" value="1" <?php checked( ! isset( $opts['enable_bale_auth'] ) || ! empty( $opts['enable_bale_auth'] ) ); ?> /> ورود با ربات بله</label>
                        <label style="display:inline-block;margin-left:16px;"><input type="checkbox" name="iramo_ai_settings[enable_sms_auth]" value="1" <?php checked( ! isset( $opts['enable_sms_auth'] ) || ! empty( $opts['enable_sms_auth'] ) ); ?> /> ورود با پنل پیامکی (SMS)</label>
                        <label style="display:inline-block;"><input type="checkbox" name="iramo_ai_settings[enable_email_auth]" value="1" <?php checked( ! isset( $opts['enable_email_auth'] ) || ! empty( $opts['enable_email_auth'] ) ); ?> /> ورود با ایمیل و رمز</label>
                    </td>
                </tr>
                <tr>
                    <th>روش ورود پیش‌فرض و مجوز ثبت‌نام</th>
                    <td>
                        <select name="iramo_ai_settings[default_auth_channel]" style="margin-left:16px;">
                            <option value="telegram" <?php selected( $opts['default_auth_channel'] ?? 'telegram', 'telegram' ); ?>>تلگرام (Telegram)</option>
                            <option value="bale" <?php selected( $opts['default_auth_channel'] ?? 'telegram', 'bale' ); ?>>پیام‌رسان بله (Bale)</option>
                            <option value="sms" <?php selected( $opts['default_auth_channel'] ?? 'telegram', 'sms' ); ?>>پیامک (SMS)</option>
                            <option value="email" <?php selected( $opts['default_auth_channel'] ?? 'telegram', 'email' ); ?>>ایمیل و رمز</option>
                        </select>
                        <label><input type="checkbox" name="iramo_ai_settings[allow_registration]" value="1" <?php checked( ! isset( $opts['allow_registration'] ) || ! empty( $opts['allow_registration'] ) ); ?> /> فعال بودن تب «ایجاد حساب جدید» برای کاربران تازه</label>
                    </td>
                </tr>
                <tr>
                    <th>نکات سریع روز (ابزارک صفحه مقالات)</th>
                    <td>
                        <textarea name="iramo_ai_settings[quick_tips_text]" rows="3" class="large-text" placeholder="هر خط را به عنوان یک نکته سریع روز بنویسید..."><?php echo esc_textarea( $opts['quick_tips_text'] ?? '' ); ?></textarea>
                        <p class="description">هر خط در این کادر مستقیماً در ابزارک «نکته سریع روز» صفحه مقالات نمایش داده می‌شود.</p>
                    </td>
                </tr>
                <tr>
                    <th>یوزرنیم و توکن ربات تلگرام</th>
                    <td>
                        <input type="text" dir="ltr" name="iramo_ai_settings[telegram_bot_username]" value="<?php echo esc_attr( $opts['telegram_bot_username'] ?? '@iRamoBot' ); ?>" placeholder="@iRamoBot" style="width:160px;margin-left:8px;" />
                        <input type="text" dir="ltr" name="iramo_telegram_bot_token" value="<?php echo esc_attr( get_option( 'iramo_telegram_bot_token' ) ); ?>" class="regular-text" placeholder="123456:ABC..." />
                    </td>
                </tr>
                <tr>
                    <th>یوزرنیم و توکن ربات بله (Bale)</th>
                    <td>
                        <input type="text" dir="ltr" name="iramo_ai_settings[bale_bot_username]" value="<?php echo esc_attr( $opts['bale_bot_username'] ?? '@iRamoBaleBot' ); ?>" placeholder="@iRamoBaleBot" style="width:160px;margin-left:8px;" />
                        <input type="text" dir="ltr" name="iramo_bale_bot_token" value="<?php echo esc_attr( get_option( 'iramo_bale_bot_token' ) ); ?>" class="regular-text" placeholder="987654:XYZ..." />
                    </td>
                </tr>
                <tr>
                    <th>چت آیدی مدیر (Admin Chat ID)</th>
                    <td><input type="text" dir="ltr" name="iramo_admin_chat_id" value="<?php echo esc_attr( get_option( 'iramo_admin_chat_id' ) ); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th>درگاه پنل پیامکی (SMS Gateway)</th>
                    <td>
                        <select name="iramo_ai_settings[sms_provider]">
                            <option value="kavenegar" <?php selected( $opts['sms_provider'] ?? 'kavenegar', 'kavenegar' ); ?>>کاوه‌نگار (Kavenegar)</option>
                            <option value="melipayamak" <?php selected( $opts['sms_provider'] ?? 'kavenegar', 'melipayamak' ); ?>>ملی‌پیامک (Melipayamak)</option>
                            <option value="faraz" <?php selected( $opts['sms_provider'] ?? 'kavenegar', 'faraz' ); ?>>فراز اس‌ام‌اس (FarazSMS)</option>
                            <option value="custom" <?php selected( $opts['sms_provider'] ?? 'kavenegar', 'custom' ); ?>>وب‌سرویس اختصاصی (Webhook)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>کلید API پنل پیامکی</th>
                    <td><input type="text" dir="ltr" name="iramo_ai_settings[sms_api_key]" value="<?php echo esc_attr( $opts['sms_api_key'] ?? '' ); ?>" class="regular-text" placeholder="API Key..." /></td>
                </tr>
                <tr>
                    <th>کد پترن (Pattern) و سرشماره ارسال</th>
                    <td>
                        <input type="text" dir="ltr" name="iramo_ai_settings[sms_pattern_code]" value="<?php echo esc_attr( $opts['sms_pattern_code'] ?? 'iramo-verify-otp' ); ?>" placeholder="Pattern Code" style="width:200px;margin-left:8px;" />
                        <input type="text" dir="ltr" name="iramo_ai_settings[sms_sender]" value="<?php echo esc_attr( $opts['sms_sender'] ?? '' ); ?>" placeholder="3000..." style="width:160px;" />
                    </td>
                </tr>
            </table>
            <?php submit_button( 'ذخیره تنظیمات سایت، فونت و درگاه‌های ورود' ); ?>
        </form>

        <div style="background:#fff;padding:24px;border-radius:12px;border:1px solid #dcdcde;margin-top:20px;">
            <h2>مدیریت و پاکسازی داده‌های نمونه (Demo Data)</h2>
            <p>در هر زمان می‌توانید تمام دوره‌ها، مقالات و ابزارهای نمونه اولیه را با یک کلیک حذف کنید تا سایت برای محتوای اختصاصی شما آماده شود.</p>
            <div style="display:flex;gap:12px;margin-top:14px;">
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'iramo_demo_nonce' ); ?>
                    <input type="hidden" name="action" value="iramo_manage_demo_data" />
                    <input type="hidden" name="demo_action" value="purge_demo" />
                    <button type="submit" class="button button-secondary" style="color:#b91c1c;border-color:#fca5a5;">پاکسازی کامل داده‌های نمونه</button>
                </form>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'iramo_demo_nonce' ); ?>
                    <input type="hidden" name="action" value="iramo_manage_demo_data" />
                    <input type="hidden" name="demo_action" value="install_demo" />
                    <button type="submit" class="button button-primary">نصب داده‌های نمونه</button>
                </form>
            </div>
        </div>
    </div>
    <?php
}
