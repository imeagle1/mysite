<?php
/**
 * iRamoAi Theme Functions & Elementor Pro Location Integration
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'after_setup_theme', function() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ] );
    register_nav_menus( [
        'primary' => __( 'منوی اصلی سایت', 'iramo-ai-theme' ),
        'footer'  => __( 'منوی فوتر', 'iramo-ai-theme' ),
    ] );
} );

// Enqueue Vazirmatn Font & Base Theme Stylesheet
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style( 'iramo-vazirmatn', 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap', [], null );
    wp_enqueue_style( 'iramo-theme-style', get_stylesheet_uri(), [ 'iramo-vazirmatn' ], '2.1.0' );
} );

// Full Elementor Pro Theme Builder Location Support
add_action( 'elementor/theme/register_locations', function( $elementor_theme_manager ) {
    $elementor_theme_manager->register_all_core_location();
} );
