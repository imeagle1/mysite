<?php
/**
 * Main Index & Canvas Template Entry for iRamoAi Theme
 */
get_header();
?>
<main id="primary" class="iramo-canvas-wrapper">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            the_content();
        endwhile;
    else :
        echo do_shortcode( '[iramo_site view="home"]' );
    endif;
    ?>
</main>
<?php
get_footer();
